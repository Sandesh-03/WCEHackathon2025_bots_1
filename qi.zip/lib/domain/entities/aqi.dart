class AQI {
  final int value;
  final String location;

  AQI({required this.value, required this.location,});
}
