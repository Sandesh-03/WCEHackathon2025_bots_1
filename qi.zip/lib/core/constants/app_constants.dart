class AppConstants {
  static const String aqiApiKey = '5dab1b7001156ab0a0d76e004f6e77d2ec0863a9';
  static const String weatherApiKey = '8c1abbc4a263f7442e86f3e30e04fbc3';
}
