import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class ChatScreen extends StatefulWidget {
  final String apiData;
  const ChatScreen({super.key, required this.apiData});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late GenerativeModel model;
  String reportSummary = "Report will be generated here.";
  bool isGeneratingReport = false;
  final String geminiApiKey = "YOUR_GEMINI_API_KEY";

  @override
  void initState() {
    super.initState();
    model = GenerativeModel(model: "gemini-2.0-flash", apiKey: geminiApiKey);
  }

  Future<void> generateReport() async {
    setState(() {
      isGeneratingReport = true;
      reportSummary = "Generating Report...";
    });

    try {
      final prompt = "Analyze this air quality data:\n\n${widget.apiData}";
      final response = await model.generateContent([Content.text(prompt)]);
      setState(() {
        reportSummary = response.text ?? "No report generated.";
      });
    } catch (e) {
      setState(() {
        reportSummary = "Error generating report: $e";
      });
    } finally {
      setState(() {
        isGeneratingReport = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Chat & AI Report")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(onPressed: generateReport, child: const Text("Generate Report")),
            const SizedBox(height: 10),
            isGeneratingReport
                ? const CircularProgressIndicator()
                : MarkdownBody(data: reportSummary),
          ],
        ),
      ),
    );
  }
}
