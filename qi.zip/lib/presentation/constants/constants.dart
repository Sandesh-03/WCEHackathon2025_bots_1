import 'package:flutter/material.dart';

const TextStyle kAppbarStyle = TextStyle(
fontWeight: FontWeight.bold,
fontSize: 25,


);
